package com.cognizant.truyum.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.truyum.dao.CartDao;
import com.cognizant.truyum.dao.CartDaoSqlImpl;
import com.cognizant.truyum.dao.CartEmptyException;

@WebServlet("/ShowCart")
public class ShowCartServelt extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ShowCartServelt() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		long userId = 1L;
		CartDao cartDao = new CartDaoSqlImpl();
		try {
			if (cartDao.getAllCartItems(userId) == null) {
				request.getRequestDispatcher("/cart-empty.jsp").forward(request, response);
			}			
		} catch (CartEmptyException e) {
			request.getRequestDispatcher("/cart-empty.jsp").forward(request, response);
			e.printStackTrace();
		}

		try {			
			request.setAttribute("menuItemList", cartDao.getAllCartItems(userId));			
			request.getRequestDispatcher("/cart.jsp").forward(request, response);
		} catch (CartEmptyException e) {
			request.getRequestDispatcher("/cart-empty.jsp").forward(request, response);
			e.printStackTrace();
		}
		
		

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
