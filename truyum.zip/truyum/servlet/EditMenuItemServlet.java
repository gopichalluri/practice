package com.cognizant.truyum.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cognizant.truyum.dao.MenuItemDao;
import com.cognizant.truyum.dao.MenuItemDaoSqlImpl;
import com.cognizant.truyum.model.MenuItem;


@WebServlet("/EditMenuItem")
public class EditMenuItemServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public EditMenuItemServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		long id = Long.parseLong(request.getParameter("menuItem"));
		String name = request.getParameter("title");
		float price = Float.parseFloat(request.getParameter("price"));
		boolean active = false;
		if(request.getParameter("inStock").equals("Yes")) {
			active = true;
		}
		Date dateOfLaunch = null;
		try {
			dateOfLaunch = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("dateoflaunch"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String category = request.getParameter("category");
		boolean freeDelivery = false;
		if(!(request.getParameter("freeDelivery") == null))
		{
		if (request.getParameter("freeDelivery").equals("Yes")) {
			freeDelivery = true;
		}
		}
		
		MenuItem menuItem = new MenuItem(id, name, price, active, dateOfLaunch, category, freeDelivery);
		
		MenuItemDao menuItemDao = new MenuItemDaoSqlImpl();
		menuItemDao.modifyMenuItem(menuItem);		
		
		request.getRequestDispatcher("/edit-menu-item-status.jsp").forward(request, response);
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
