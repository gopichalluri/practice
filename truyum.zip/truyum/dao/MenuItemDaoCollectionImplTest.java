package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImplTest {

	public static void main(String[] args) {

		testGetMenuItemListAdmin();
		testGetMenuItemListCustomer();
		testModifyMenuItem();
		// testGetMenuItem();
	}

	public static void testGetMenuItemListAdmin() {

		ArrayList<MenuItem> list = new ArrayList<MenuItem>();

		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		list.addAll(menuItemDao.getMenuItemListAdmin());

		Iterator<MenuItem> iterator = list.iterator();
		while (iterator.hasNext()) {
			MenuItem menuItem = (MenuItem) iterator.next();
			System.out.println(menuItem);			
		}		

	}

	public static void testGetMenuItemListCustomer() {
		ArrayList<MenuItem> list = new ArrayList<MenuItem>();

		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		list.addAll(menuItemDao.getMenuItemListCustomer());

		Iterator<MenuItem> iterator = list.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());

		}
	}

	public static void testModifyMenuItem() {
		try {
			MenuItem menuItem = new MenuItem(1L, "test", 99.00f, true, DateUtil.convertToDate("15/03/2017"),
					"Main Course", true);

			MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
			menuItemDao.modifyMenuItem(menuItem);

			System.out.println(menuItemDao.getMenuItem(1L));
		} catch (ParseException e) {

			e.printStackTrace();
		}

	}

	public static void testGetMenuItem() {

		/*
		 * MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();
		 * 
		 * System.out.println(menuItemDao.getMenuItem(1L));
		 */

	}

}
