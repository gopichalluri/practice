package com.cognizant.truyum.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

public class CartDaoSqlImpl implements CartDao {

	@Override
	public void addCartItem(long userId, long menuItemId) {

		Connection connection = ConnectionHandler.getConnection();	

		String sqlQuery = "insert into cart (ct_us_id,ct_pr_id) values('" + userId + "', " + menuItemId + ");";

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

	}

	@Override
	public Cart getAllCartItems(long userId) throws CartEmptyException {
		Connection connection = ConnectionHandler.getConnection();
		ArrayList<MenuItem> menuItems = new ArrayList<MenuItem>();

		String sqlQuery = "select * from menu_item  inner join cart on cart.ct_pr_id = menu_item.me_id where cart.ct_us_id = '"+userId  + "';";
		double total = 0.0d;	

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				MenuItem menuItem = new MenuItem(resultSet.getInt("me_id"), resultSet.getString("me_name"),
						resultSet.getFloat("me_price"), resultSet.getBoolean("me_active"),
						resultSet.getDate("me_date_of_launch"), resultSet.getString("me_category"),
						resultSet.getBoolean("me_free_delivery"));
				menuItems.add(menuItem);
				total += resultSet.getDouble("me_price");
			}

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		
		if (menuItems.isEmpty()) {
			throw new CartEmptyException();
		}

		Cart cart = new Cart(menuItems, total);

		return cart;
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {
		
		Connection connection = ConnectionHandler.getConnection();
		
		String sqlQuery = "delete from cart where ct_us_id = '" + userId + "'and ct_pr_id = '" + menuItemId +"' ;";
		
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.executeUpdate();			

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		
	}

}
