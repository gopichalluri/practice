package com.cognizant.truyum.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

//import com.mysql.jdbc.Connection;
import java.sql.Connection;

public class ConnectionHandler {

	public static Connection getConnection() {
		String file = "C:\\Users\\802646\\Desktop\\truYum\\src\\connection.properties";
		Properties properties = new Properties();
		FileInputStream fileInputStream = null;
		Connection connection = null;

		try {
			fileInputStream = new FileInputStream(file);
			properties.load(fileInputStream);
			fileInputStream.close();

			String driver = properties.getProperty("driver");
			if (driver != null) {
				Class.forName(driver);
			}

			String url = properties.getProperty("connection-url");
			String username = properties.getProperty("user");
			String password = properties.getProperty("password");			
			connection = DriverManager.getConnection(url, username, password);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return connection;

	}

}
