package com.cognizant.truyum.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoSqlImplTest {

	public static void main(String[] args) {

		testModifyMenuItem();

	}

	public static void testGetMenuItemListAdmin() {

		ArrayList<MenuItem> list = new ArrayList<MenuItem>();

		MenuItemDao menuItemDao = new MenuItemDaoSqlImpl();
		list.addAll(menuItemDao.getMenuItemListAdmin());

		Iterator<MenuItem> iterator = list.iterator();
		while (iterator.hasNext()) {
			MenuItem menuItem = (MenuItem) iterator.next();
			System.out.println(menuItem);
		}

	}
	
	public static void testGetMenuItemListCustomer() {

		ArrayList<MenuItem> list = new ArrayList<MenuItem>();

		MenuItemDao menuItemDao = new MenuItemDaoSqlImpl();
		list.addAll(menuItemDao.getMenuItemListCustomter());

		Iterator<MenuItem> iterator = list.iterator();
		while (iterator.hasNext()) {
			MenuItem menuItem = (MenuItem) iterator.next();
			System.out.println(menuItem);
		}

	}
	
	public static void testModifyMenuItem() {
		try {
			MenuItem menuItem = new MenuItem(1L, "Sandwich", 99.00f, true, DateUtil.convertToDate("15/03/2017"),
					"Main Course", true);

			MenuItemDao menuItemDao = new MenuItemDaoSqlImpl();
			menuItemDao.modifyMenuItem(menuItem);

			System.out.println(menuItemDao.getMenuItem(1L));
		} catch (ParseException e) {

			e.printStackTrace();
		}

	}

	public static void testGetMenuItem() {

		MenuItemDao menuItemDao = new MenuItemDaoSqlImpl();

		System.out.println(menuItemDao.getMenuItem(5L));

	}
	
	

}
