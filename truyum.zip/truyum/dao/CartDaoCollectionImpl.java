package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

public class CartDaoCollectionImpl implements CartDao {
	static private HashMap<Long, Cart> userCarts;

	public CartDaoCollectionImpl() {
		if (userCarts == null) {
			userCarts = new HashMap<Long, Cart>();
		}
	}

	@Override
	public void addCartItem(long userId, long menuItemId) {
		MenuItemDao menuItemDao = new MenuItemDaoCollectionImpl();

		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);

		ArrayList<MenuItem> list = new ArrayList<MenuItem>();

		if (userCarts.containsKey(userId)) {
			list.addAll(userCarts.get(userId).getMenuItemList());
			list.add(menuItem);
			Cart cart = new Cart(list, 0.0d);
			userCarts.put(userId, cart);
		} else {
			list.add(menuItem);
			Cart cart = new Cart(list, 0.0d);
			userCarts.put(userId, cart);
		}

	}

	@Override
	public Cart getAllCartItems(long userId) throws CartEmptyException {
		ArrayList<MenuItem> list = new ArrayList<MenuItem>();

		double total = 0.0d;		
		Cart cart = null;

		if (userCarts.containsKey(userId)) {

			list.addAll(userCarts.get(userId).getMenuItemList());

			if (list.isEmpty()) {
				throw new CartEmptyException();
			}

			Iterator<MenuItem> iterator = list.iterator();

			while (iterator.hasNext()) {
				MenuItem menuItem = (MenuItem) iterator.next();

				total += menuItem.getPrice();
				cart = new Cart(list, total);

			}
		}

		return cart;
	}

	@Override
	public void removeCartItem(long userId, long menuItemId) {

		ArrayList<MenuItem> list = new ArrayList<MenuItem>();

		if (userCarts.containsKey(userId)) {

			list.addAll(userCarts.get(userId).getMenuItemList());

			for (int i = 0; i < list.size(); i++) {
				if (list.get(i).getId() == menuItemId) {
					list.remove(i);
					Cart cart = new Cart(list, 0.0d);
					userCarts.put(userId, cart);
				}

			}
		}

	}

}
