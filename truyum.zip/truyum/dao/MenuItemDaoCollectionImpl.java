package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.util.DateUtil;

public class MenuItemDaoCollectionImpl implements MenuItemDao {
	static private List<MenuItem> menuItemList;

	public MenuItemDaoCollectionImpl() {

		if (menuItemList == null) {
			menuItemList = new ArrayList<MenuItem>();
			try {
				MenuItem menuItem1 = new MenuItem(1L, "Sandwich", 99.00f, true, DateUtil.convertToDate("15/03/2017"),
						"Main Course", true);
				MenuItem menuItem2 = new MenuItem(2L, "Burger", 129.00f, true, DateUtil.convertToDate("23/12/2017"),
						"Main Course", false);
				MenuItem menuItem3 = new MenuItem(3L, "Pizza", 149.00f, true, DateUtil.convertToDate("21/08/2018"),
						"Main Course", false);
				MenuItem menuItem4 = new MenuItem(4L, "French Fries", 57.00f, false,
						DateUtil.convertToDate("02/07/2017"), "Starters", true);
				MenuItem menuItem5 = new MenuItem(5L, "Chocolate Brownie", 32.00f, true,
						DateUtil.convertToDate("02/11/2022"), "Dessert", true);

				menuItemList.add(menuItem1);
				menuItemList.add(menuItem2);
				menuItemList.add(menuItem3);
				menuItemList.add(menuItem4);
				menuItemList.add(menuItem5);
			} catch (Exception e) {

			}
		}
	}

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		ArrayList<MenuItem> arrayList = new ArrayList<MenuItem>();

		Date today = new Date();

		Iterator<MenuItem> iterator = menuItemList.iterator();

		while (iterator.hasNext()) {
			MenuItem menuItem = (MenuItem) iterator.next();

			if (menuItem.isActive() == true) {
				if (menuItem.getDateOfLaunch().compareTo(today) < 0) {
					arrayList.add(menuItem);
				}
			}
		}
		return arrayList;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		Iterator<MenuItem> iterator = menuItemList.iterator();
		MenuItem menuItem2 = null;

		while (iterator.hasNext()) {
			menuItem2 = (MenuItem) iterator.next();

			if (menuItem.getId() == menuItem2.getId()) {
				menuItemList.set(menuItemList.indexOf(menuItem2), menuItem);
				// System.out.println(menuItem2);
			}
		}

	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		Iterator<MenuItem> iterator = menuItemList.iterator();

		MenuItem menuItem = null;

		while (iterator.hasNext()) {
			menuItem = (MenuItem) iterator.next();

			if (menuItem.getId() == menuItemId) {
				return menuItem;
			}

		}
		return menuItem;
	}

}
