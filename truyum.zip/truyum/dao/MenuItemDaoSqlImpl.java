package com.cognizant.truyum.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import com.cognizant.truyum.model.MenuItem;
import java.sql.Connection;

public class MenuItemDaoSqlImpl implements MenuItemDao {

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		Connection connection = ConnectionHandler.getConnection();
		ArrayList<MenuItem> menuItems = new ArrayList<MenuItem>();

		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from menu_item");
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				MenuItem menuItem = new MenuItem(resultSet.getInt("me_id"), resultSet.getString("me_name"),
						resultSet.getFloat("me_price"), resultSet.getBoolean("me_active"),
						resultSet.getDate("me_date_of_launch"), resultSet.getString("me_category"),
						resultSet.getBoolean("me_free_delivery"));
				menuItems.add(menuItem);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return menuItems;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		Connection connection = ConnectionHandler.getConnection();
		ArrayList<MenuItem> menuItems = new ArrayList<MenuItem>();

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"select * FROM menu_item where me_date_of_launch < CURDATE() and me_active = true;");
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				MenuItem menuItem = new MenuItem(resultSet.getInt("me_id"), resultSet.getString("me_name"),
						resultSet.getFloat("me_price"), resultSet.getBoolean("me_active"),
						resultSet.getDate("me_date_of_launch"), resultSet.getString("me_category"),
						resultSet.getBoolean("me_free_delivery"));
				menuItems.add(menuItem);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return menuItems;

	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {

		Connection connection = ConnectionHandler.getConnection();

		String date = new SimpleDateFormat("yyyy-MM-dd").format(menuItem.getDateOfLaunch());
		
		String sqlQuery = "update menu_item set me_name = '" + menuItem.getName() + "', me_price = '"
				+ menuItem.getPrice() + "', me_active = '" + (menuItem.isActive() ? "1" : "0")
				+ "', me_date_of_launch = '" + date + "', me_category = '" + menuItem.getCategory()
				+ "', me_free_delivery = '" + (menuItem.isFreeDelivery() ? "1" : "0") + "' where me_id = '"
				+ menuItem.getId() + "';";

		try {
			PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {

		Connection connection = ConnectionHandler.getConnection();
		MenuItem menuItem = null;

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * FROM truyum.menu_item where me_id = " + menuItemId + ";");
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				menuItem = new MenuItem(resultSet.getInt("me_id"), resultSet.getString("me_name"),
						resultSet.getFloat("me_price"), resultSet.getBoolean("me_active"),
						resultSet.getDate("me_date_of_launch"), resultSet.getString("me_category"),
						resultSet.getBoolean("me_free_delivery"));
			}
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return menuItem;

	}

}
